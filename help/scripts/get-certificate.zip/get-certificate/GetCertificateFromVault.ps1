$ScriptDir = Split-Path $script:MyInvocation.MyCommand.Path
Push-Location $ScriptDir

# set fixed input values
$OldApiRoot = 'https://ealicenses-acc.everyangle.org/api/'
$ApiRoot = 'https://nl-ealicenses-cicd.eatestad.local/api/'

$createCertificateEndPoint = $ApiRoot + "License/generate"
$Organization = "OR.11.0010"
$ModelIds = @("EA2_800","EA3_800","EA5_800","EA8_800","EA9_800","EA4IT")

# figure out on which machine we're running
$LocalMachineCIM = Get-CimInstance -ClassName CIM_ComputerSystem
$LocalFQDN = $LocalMachineCIM.DNSHostName+"."+$LocalMachineCIM.Domain
$ServerFQDN = $LocalFQDN

Write-Host "----------------------------------------"

# get the credentials for the EAVault
$VaultUser = Read-Host 'EAVault username?'
$PWord_Secure = Read-Host 'EAVault password?' -AsSecureString

$SpecifiedFQDN = Read-Host 'FQDN? (empty for this machine)'

if ([string]::IsNullOrEmpty($SpecifiedFQDN))
{
	Write-Host "Using FQDN of the current machine."
	$ServerFQDN = $LocalFQDN
}
else
{
	Write-Host "Using specified FQDN."
	$ServerFQDN = $SpecifiedFQDN
}

$Expiration = Get-Date( (Get-Date).AddYears(5)) -Format "MM\/dd\/yyyy"
#$ScriptDir = Split-Path $script:MyInvocation.MyCommand.Path
$zipLocation = "${ScriptDir}\Certificate-${Organization}-${ServerFQDN}.zip"
$certificateLocation = "${ScriptDir}\EAVault-Content\"

# report the values that will be used
Write-Host "----------------------------------------"
Write-Host "Retrieving certificates and license for:"
Write-Host "Organization    :" $Organization
Write-Host "Machine         :" $ServerFQDN
Write-Host "Expiration      :" $Expiration
Write-Host "Models          :" ($ModelIds -join ', ')
Write-Host "EAVault API     :" $createCertificateEndPoint
Write-Host "Output ZIP file :" $zipLocation
Write-Host "----------------------------------------"
Write-Host ""

# Build the request body using the specified settings
$RequestBody = @"
{
	"general_webserver_license": {
		"fully_qualified_domain_name": "${ServerFQDN}"
	},
	"application_server_license": {
		"expires_format": "${Expiration}",
		"fqdn": "${ServerFQDN}"
	},
	"model_licenses": [

"@

$i = 0	
foreach ($ModelId in $ModelIds)
{
	$i = $i + 1
	if ($i -gt 1)
	{
		$RequestBody = $RequestBody + ','
	}
	
	$RequestBody = $RequestBody + @"
		{
			"expires_format": "${Expiration}",
			"model_id": "${ModelId}",
			"fqdn1": "${ServerFQDN}"
		}
"@
}
 
$RequestBody = $RequestBody + @"
	],
	"etl_server": {
		"fully_qualified_domain_name": "${ServerFQDN}"
	},
	"sts": {
		"fully_qualified_domain_name": "${ServerFQDN}"
	},
	"repository": {
		"fully_qualified_domain_name": "${ServerFQDN}"
	},
	"organizationSerial": "${Organization}"
}
"@

# Build credentials
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $VaultUser, $PWord_Secure

$HeadersDictionary = @{}
$HeadersDictionary.Add('accept','application/json')
$HeadersDictionary.Add('Content-Type','application/json')

# delete the zipfile if it already exists
if ([System.IO.File]::Exists($zipLocation))
{
	Write-Host "Removing existing EAVault response file"
	Remove-Item -Path $zipLocation -Force
}

# remove the folder where the zipfile from the EAVault will be extracted
if ([System.IO.Directory]::Exists($certificateLocation))
{
	Write-Host "Removing existing EAVault content folder"
	#Remove-Item -Recurse -Force $certificateLocation
	[System.IO.Directory]::Delete($certificateLocation)
}
mkdir -Force $certificateLocation

# Call the EAVault API to get the zip with certificates and license
Write-Host "Getting certificate/license zip from EAVault..."
$Result = Invoke-RestMethod -Method 'POST' -Uri $createCertificateEndPoint -Credential $Credential -Headers $HeadersDictionary -Body $RequestBody -OutFile $zipLocation -TimeoutSec 120

if (-Not [System.IO.File]::Exists($zipLocation))
{
	Write-Host "Unable to get file from EAVault!" -ForegroundColor Red
	return $false
}

Write-Host "Received license and certificates from the EAVault" -ForegroundColor Green
Write-Host "Extracting archive..."

Expand-Archive -LiteralPath $zipLocation -DestinationPath $certificateLocation -Force

# just lazy now: copy the import script into the new folder (easier if that script can operate [manually] on contained folder too)
Copy-Item ".\ImportEACertificates.ps1.resource" -Destination ".\EAVault-Content\ImportEACertificates.ps1"
Copy-Item ".\ImportEACertificates.bat.resource" -Destination ".\EAVault-Content\ImportEACertificates.bat"

if ([string]::IsNullOrEmpty($SpecifiedFQDN))
{
	Write-Host "Execute the batch file in the EAVault-Content subfolder to import the downloaded certificates." -ForegroundColor Blue
}
else
{
	Write-Host "Copy the EAVault-Content subfolder to the machine with the specified FQDN and execute the batch file in the folder using PowerShell 6 to import the downloaded certificates." -ForegroundColor Blue
}