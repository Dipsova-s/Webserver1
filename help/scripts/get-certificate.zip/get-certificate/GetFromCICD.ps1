$ApiRoot = 'https://nl-ealicenses-cicd.eatestad.local/api/'

$createCertificateEndPoint = $ApiRoot + "License/generate"
$Organization = "OR.11.0010"
$ModelIds = @("EA2_800","EA3_800","EA5_800","EA8_800","EA9_800","EA4IT")

$VaultUser = Read-Host 'EAVault username?'
$PWord = Read-Host -AsSecureString 'EAVault password?'

.\GetCertificatesFromCICDVault.ps1 $ApiRoot $VaultUser $PWord $ModelIds