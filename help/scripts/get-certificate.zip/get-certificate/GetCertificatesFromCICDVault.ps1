########################
#   NOTE: This is PowerShell 6 compatible and not PowerShell 5
########################

param(
    $ApiRoot,
    $User,
    $PWord,
    [string[]]$ModelIds
)


########################
#   Setup vars required
########################

Write-Host "$env:Computername - connected"

#PSCredential
$PWord_Secure = ConvertTo-SecureString -String $PWord -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord_Secure

#File locations
$certificateLocation = "C:\TestServer\Data\Certificates\"
$licenseLocation = "C:\TestServer\Data\Cmdini\"
$licenseFile = "C:\TestServer\Data\Cmdini\license.json"

#Other vars
$today = Get-Date -Format "MM/dd/yyyy"
$nextYear = Get-Date( (Get-Date).AddYears(1)) -Format "MM/dd/yyyy"
$FQDN=(Get-CimInstance -ClassName win32_computersystem).DNSHostName+"."+(Get-CimInstance -ClassName win32_computersystem).Domain
$createLicenseEndPoint = $ApiRoot + "license/generate"

$requestString = "{
    'license_id': null,
    'license_type': null,
    'expires': 0,
    'expires_rfc1123': null,
    'file_description': {
        'file_contents': null,
        'created': 0,
        'created_rfc1123': null,
        'created_by': null,
        'created_machine': null
    },
    'general_license': {
        'id': null,
        'system_id': '-1',
        'system_name': '$FQDN',
        'system_description': 'Test system for $FQDN'
    },
    'general_webserver_license': {
        'fully_qualified_domain_name': '$FQDN',
        'system_info': null
    },
    'application_server_license': {
        'license_id': null,
        'license_type': null,
        'expires_format': '$nextYear',
        'expires': 0,
        'expires_rfc1123': null,
        'fqdn': '$FQDN',
        'ip_addresses': [],
        'max_models': null,
        'max_named_users': null,
        'max_concurrent_users': null,
        'features': [
            {
                'feature': 'AngleAutomation',
                'licensed': true
            },
            {
                'feature': 'OdataService',
                'licensed': true
            },
            {
                'feature': 'ETLDesigner',
                'licensed': true,
                'licensekey': 'Test',
                'fqdn': '$FQDN',
                'install_date': '$today'
            },
            {
                'feature': 'ProcessMining',
                'licensed': true
            }
        ],
        'license_signature': null,
        'license': null,
        'system_info': null
    },
    'etl_server': {
        'licensekey': null,
        'fully_qualified_domain_name': '$FQDN',
        'install_date': '$today'
    },
    'sts': {
        'fully_qualified_domain_name': '$FQDN'
    },
    'repository': {
        'fully_qualified_domain_name': '$FQDN'
    },
    'model_licenses': [
        "
        foreach ($ModelId in $ModelIds) {

            $requestString = $requestString + "{
                        'license_id': '',
                        'license_type': '',
                        'expires_format': '$nextYear',
                        'expires': 0,
                        'expires_rfc1123': '',
                        'ip_addresses': [],
                        'model_id': '$ModelId',
                        'max_users': null,
                        'max_modelservers': null,
                        'licensed_apps': [
                            'AFS',
                            'Basis',
                            'GRC',
                            'GRCKPMG',
                            'P2P',
                            'Retail',
                            'SAPHRM',
                            'SCM',
                            'Fashion',
                            'FiCo',
                            'O2C',
                            'PM',
                            'SAP',
                            'SAPSCM'
                        ],
                        'efs_required': false,
                        'license_signature': '',
                        'license': '',
                        'type': 0,
                        'is_multi_host': false,
                        'slave_type': '',
                        'is_dual_instance': false,
                        'datasource': 0,
                        'sap_database_type': '',
                        'non_sap_datasource_type': '',
                        'host1': {
                            'memory': null,
                            'disk_space': null,
                            'cpu_cores': null,
                            'version': ''
                        },
                        'host2': {
                            'memory': null,
                            'disk_space': null,
                            'cpu_cores': null,
                            'version': ''
                        },
                        'host3': {
                            'memory': null,
                            'disk_space': null,
                            'cpu_cores': null,
                            'version': ''
                        },
                        'fqdn1': '$FQDN',
                        'fqdn2': '',
                        'fqdn3': ''
                    },
                "
        }

        $requestString = $requestString + "
    ],
    'license_signature': null,
    'license': null,
    'certificate_version': 2,
    'licenseId': null,
    'organizationId': 'OR.11.0010',
    'organizationSerial': 'OR.11.0010',
    'organizationName': 'Every Angle Nederland'
}"

########################
#   Create new "System" for EA client
########################
$zipLocation = $certificateLocation + "Certificate.zip"

$Result = Invoke-RestMethod -Method 'POST' -Uri $createLicenseEndPoint -Credential $Credential -Body $requestString  -OutFile $zipLocation -ContentType "application/json" -SkipCertificateCheck -AllowUnencryptedAuthentic
